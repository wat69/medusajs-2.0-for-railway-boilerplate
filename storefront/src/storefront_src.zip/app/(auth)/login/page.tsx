import LoginTemplate from "@modules/account/templates/login-template"

export default function LoginPage() {
  return <LoginTemplate />
}
