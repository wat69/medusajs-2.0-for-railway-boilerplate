'use server'

import { cookies } from 'next/headers'
import medusa from 'app/medusa-client'

export async function login(_: any, formData: FormData) {
  const email = formData.get('email')
  const password = formData.get('password')

  if (!email || !password) {
    return 'Email och lösenord krävs.'
  }

  try {
    const { access_token } = await medusa.auth.authenticate({
      email: email.toString(),
      password: password.toString(),
    })

    cookies().set('_medusa_jwt', access_token, {
      httpOnly: true,
      path: '/',
      secure: true,
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7, // 7 dagar
    })

    return null
  } catch (error: any) {
    console.error('[Login error]', error)
    return error?.message || 'Inloggningen misslyckades.'
  }
}
